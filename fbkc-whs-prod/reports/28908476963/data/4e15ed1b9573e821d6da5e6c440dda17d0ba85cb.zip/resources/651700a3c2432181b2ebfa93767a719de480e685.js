__turbopack_load_page_chunks__("/", [
  "static/chunks/b21dba24d6991b2a.js",
  "static/chunks/67cc7889df67a985.js",
  "static/chunks/f6a3599d24534593.js",
  "static/chunks/37c1b0010c4bab81.js",
  "static/chunks/cfbfbe16d3bc560a.js",
  "static/chunks/7cdd580e2e53672f.js",
  "static/chunks/a6dc7f568aeda2ab.js",
  "static/chunks/30b9d646ee16f51b.js",
  "static/chunks/b69c2f3ddc6fdf3b.js",
  "static/chunks/7c2d9a862d59ce02.js",
  "static/chunks/12f3864d6ab8e746.js",
  "static/chunks/e14f730aaccdcc8b.js",
  "static/chunks/1bfd8ca97911728c.js",
  "static/chunks/dbeab8c7c00a2db6.js",
  "static/chunks/3675d7e5c61e5516.js",
  "static/chunks/turbopack-80e519247e05121b.js"
])
